Hamza Jad Al Aoun, Meriem Driss
